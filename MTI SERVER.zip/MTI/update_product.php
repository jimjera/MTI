<?php

/*
 * Following code will create a new product row
 * All product details are read from HTTP Post Request
 */

// array for JSON response
$response = array();

// check for required fields
//if (isset($_POST['name']) && isset($_POST['price']) && isset($_POST['description'])) {
    
    $facility = $_POST['facility'];
    $name =$_POST['name'];
    $date = $_POST['date'];
    
    $opd= $_POST['opd'];
    $malaria= $_POST['malaria'];
    $awd=$_POST['awd'];
    $padaetric= $_POST['padaetric'];
    $mental= $_POST['mental'];
    $admisions=$_POST['admisions'];
    $surgical= $_POST['surgical'];

    $ipd= $_POST['ipd'];
    $death= $_POST['death'];
    $exits= $_POST['exits'];
    $mdr= $_POST['mdr'];
    $started= $_POST['started'];
    $tx= $_POST['tx'];
    $art=$_POST['art'];
    $lost=$_POST['lost'];

    $viral= $_POST['viral'];
    $tested= $_POST['tested'];
    $pos= $_POST['pos'];
    $visits=$_POST['visits'];
    $deli= $_POST['deli'];
    $mat= $_POST['mat'];
    $home=$_POST['home'];
    $bcg= $_POST['bcg'];
    $polio= $_POST['polio'];
    $polio2=$_POST['polio2'];
    $polio3= $_POST['polio3'];
    $measles= $_POST['measles'];

    $testedhep=$_POST['testedhep'];
    $testedheppos= $_POST['testedheppos'];
    $topic= $_POST['topic'];
    $att=$_POST['att'];
    $topicc=$_POST['topicc'];
    $loc=$_POST['locc'];
    $attt=$_POST['attt'];
    $locc=$_POST['locc1'];
    $cha= $_POST['cha'];
    $clients= $_POST['clients'];

    // include db connect class
    require_once __DIR__ . '/db_connect.php';

    // connecting to db
    $db = new DB_CONNECT();

    // mysql inserting a new row
    $result = mysql_query("INSERT INTO weeklyreport(dates,name,clients,facility,opd,awd,malaria,admissions,surgical,menya,padaetric,ipd,death,exits,mdr,started,tx,art,lost,viral,tested,pos,visits,deli,mat,home,bcg,polio1,polio2,polio3,measles,testedhep,testedheppos,topic,loc,att,topicc,locc,attt,cha) VALUES('$date','$name','$clients','$facility','$opd','$awd','$malaria','$admisions','$surgical','$mental','$padaetric','$ipd','$death','$exits','$mdr','$started','$tx','$art','$lost','$viral','$tested','$pos','$visits','$deli','$mat','$home','$bcg','$polio','$polio3','$polio3','$measles','$testedhep','$testedheppos','$topic','$loc','$att','$topicc','$locc','$attt','$cha')");

    // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
        $response["message"] = "successfully created.";
 $response["response"] = mysql_error();
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
        $response["response"] = mysql_error();
        
        // echoing JSON response
        echo json_encode($response);
    }

?>