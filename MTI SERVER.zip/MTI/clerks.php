<?php

/*
 * Following code will list all the products
 */

// array for JSON response
$response = array();


// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db
$db = new DB_CONNECT();
$username = $_GET['page'];
// get all products from products table
$result = mysql_query("SELECT *FROM weeklyreport where name='$username' ORDER BY id DESC") or die(mysql_error());

// check for empty result
if (mysql_num_rows($result) > 0) {
    // looping through all results
    // products node
    $res= array();
    
    while ($row = mysql_fetch_array($result)) {
        // temp user array
        $product = array();
        
        $product["name"] = $row["name"];
        $product["facility"] = $row["facility"];
        $product["dates"] = $row["dates"];


        $product["opd"] = $row["opd"];
        $product["awd"] = $row["awd"];
        $product["malaria"] = $row["malaria"];
        $product["adm"] = $row["admissions"];
        $product["surgical"] = $row["surgical"];
        $product["mental"] = $row["menya"];

        $product["padaetric"] = $row["padaetric"];
        $product["ipd"] = $row["ipd"];
        $product["death"] = $row["death"];
        $product["exits"] = $row["exits"];
        $product["mdr"] = $row["mdr"];


        $product["started"] = $row["started"];//started on art
      

        $product["tx"] = $row["tx"];
        $product["art"] = $row["art"];//started on art
        $product["lost"] = $row["lost"];
        $product["viral"] = $row["viral"];
        $product["clients"] = $row["clients"];
        $product["tested"] = $row["tested"];

        $product["deli"] = $row["deli"];
        $product["mat"] = $row["mat"];
        $product["home"] = $row["home"];
        $product["bcg"] = $row["bcg"];
        $product["polio"] = $row["polio"];

        $product["visits"] = $row["visits"];
        $product["pos"] = $row["pos"];
        

        $product["polio2"] = $row["polio2"];
        $product["polio3"] = $row["polio3"];
        $product["measles"] = $row["measles"];
        $product["testedhep"] = $row["testedhep"];
        $product["testedheppos"] = $row["testedheppos"];


        $product["topic"] = $row["topic"];
        $product["loc"] = $row["loc"];
        $product["att"] = $row["att"];
       

        $product["topicc"] = $row["topicc"];
        $product["locc"] = $row["locc"];
        $product["attt"] = $row["attt"];
        $product["cha"] = $row["cha"];



        // push single product into final response array
        array_push($res, $product);
    }
    // success
    //$response["success"] = 1;

    // echoing JSON response
    echo json_encode($res);
} else {
    // no products found
   // $response["success"] = 0;
    //$response["message"] = "No products found";
echo "over";
    // echo no users JSON
   // echo json_encode($response);
}
?>
